## About:
A success based roll system designed for virtual tabletop.